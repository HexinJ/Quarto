import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyOtherComputerPlayer here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyOtherComputerPlayer extends ComputerPlayer
{
  public MyOtherComputerPlayer(String name)
    {
        super(name);

    }
}
